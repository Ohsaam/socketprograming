import os

path = os.getcwd()
print(path)